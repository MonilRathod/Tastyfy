import React from 'react';
import Card from './card/card';

const RecipeCard = ({r}) => {
    return (
        <Card r={r}/>
    );
}

export default RecipeCard;


